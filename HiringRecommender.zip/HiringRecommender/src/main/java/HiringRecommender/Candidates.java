package HiringRecommender;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Candidates {
  ArrayList<String> name = new ArrayList<>();
  ArrayList<Double> GPA = new ArrayList<>();
  ArrayList<Integer> languages = new ArrayList<>();


  public Candidates(){
  }

  public void readFiles(String filename){
    Scanner in = null;
    try{
      in = new Scanner(new File(filename));
    }catch(FileNotFoundException s){
      System.out.println("404 File Not Found!!!");
    }
    in.nextLine();
    while(in.hasNextLine()){
      String words = in.nextLine(); //read in line by line
      storeData(words); //store values in our field names
    }

//  test line
//    for(int i = 0; i < name.size(); i++){
//      System.out.printf("%-20s %-5.2f %d\n", this.name.get(i), this.GPA.get(i), this.languages.get(i));
//    }
//    prints formatted list of Applicants, gpa, and # languages



  }
  public void storeData(String words){

    words = words.replaceAll(", ", " ");  //This gets rid of commas in places that would
    String[] line = words.split(",");               //affect our ability to break up lines properly
    this.name.add(line[0] + " " + line[1]);   //split line by commas
    this.GPA.add(Double.parseDouble(line[8]));  //add the parts of the line with necessary information
    this.languages.add(numSpaces(line[7])); //into their field


  }
  public int numSpaces(String words){ //count languages based on how many tokens are in the string
    Scanner in = new Scanner(words);
    int count = 0;

      while(in.hasNext()){
        in.next();
        count++;
      }
      return count;
  }
  /*
    This method takes all of the candidates with less than 3 languages out of
    our candidate pool. It then fills an array with possible candidates, checks if their GPA
    is the highest, if it is not, swaps them with the new candidate.
   */
    public int[] makeList(int[] recommendations){
    System.out.println(name.size());
    checkLanguages(); //Removes all candidates with < 3 languages
    int count = 0;
    recommendations[0] = 0;



    for(int i = 0; i < this.name.size(); i++){

      if(count < 9){
        if(this.GPA.get(i) > this.GPA.get(recommendations[count])){    //if GPA of element i is greater than the last
          count++;                                                      //last person in the list, add them
          recommendations[count] = i;
//          System.out.println(recommendations[count]);
          sortList(recommendations);
        }
      }//Sort  the list so the lowest GPA is on the bottom
      else
      if(this.GPA.get(i) > this.GPA.get(recommendations[count])){    //Once list is full

        recommendations[count] = i;
        sortList(recommendations);
      }
    }

    sortList(recommendations);
//    for(int i = 0; i < recommendations.length; i++){
//      System.out.println(i + ": " + this.GPA.get(recommendations[i]));
//    }
  return recommendations;

  }
//This instance deletes anyone from our list who knows less than 3 languages, a requirement we
//  made for our candidates
  public void checkLanguages(){
    for(int i = 0; i < name.size(); i++){

      if(this.languages.get(i) < 3){
        this.name.remove(i);
        this.GPA.remove(i);
        this.languages.remove(i);
        i--;  //when we remove elements we have to step back in the array to check all the elements
      }
    }
  }
  //Selection sort for max values
  public void sortList(int[] x) {

    for (int i = 0; i < x.length - 1; i++) {
      int max = i;
      for (int j = i + 1; j < x.length; j++) {
        if(this.GPA.get(x[j]) > this.GPA.get(x[max])){
          max = j;
        }
      }
      swap(x, i, max);
    }
  }
//  swap used with selection sort method
  public void swap(int[] x, int i, int max){
//    System.out.println(Arrays.toString(x));
    int temp = 0;
    temp = x[max];
    x[max] = x[i];
    x[i] = temp;
//    System.out.println(Arrays.toString(x));
  }


}
