package HiringRecommender;
import java.util.*;
import java.io.*;
/* I chose to use the GPA and number of languages to make my decision.
If the person knows more than 3 languages and has top GPA, they're in.
We definitely miss out on the 'human element' with this approach. Although,
some people work very hard in school and get good grades, this doesn't mean they
would handle stress in the job better than someone else. This doesn't mean that
they would be as fun to work with, or be the best team player. This approach also
didn't take into account major or what college the person went to which, depending on
the job, could be a very big distinction in their work ethic and ability to perform
compared to others, despite their grade. I say this because, obviously Ivy league schools
are said to have more difficult curriculum.

My program prints the list of the 10 candidates with best GPA.
 */
public class HiringRecommenderMain {
  public static void main(String[] args){
    int[] refer = new int[10];
    Candidates list = new Candidates();

    list.readFiles("applicant_data.csv  ");
    refer = list.makeList(refer);

    printCandidates(refer, list);
//    printAll(list);

//    System.out.println(refer[0]);
//    System.out.println(list.GPA.get(0));

  }

  public static void printCandidates(int[] refer, Candidates list){
//    System.out.println(list.name.size());
    for(int i = 0; i < refer.length; i++){
      System.out.print(i+1 + "= " + list.name.get(refer[i])+ " ");
      System.out.print(list.GPA.get(refer[i]) + " ");
      System.out.print(list.languages.get(refer[i]) + "\n");
    }
  }
  public static void printAll(Candidates list){
    list.checkLanguages();
    for(int i = 0; i < list.name.size(); i++){
      System.out.printf("%-20s %-9.2f %d\n", list.name.get(i), list.GPA.get(i), list.languages.get(i));
    }
    System.out.println(list.name.size());
  }

}
